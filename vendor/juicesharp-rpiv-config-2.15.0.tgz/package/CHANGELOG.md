## [2.15.0] - 2026-10-24

## [2.14.2] - 2026-10-23

## [2.14.1] - 2026-10-23

## [2.14.0] - 2026-10-23

## [2.13.10] - 2026-10-23

## [2.13.9] - 2026-10-17

### Changed

- Faster extension startup: relative imports now name the published `.ts` files instead of nonexistent `.js` targets, so Pi's loader (jiti) no longer runs fallback resolution for each of them on every launch. Runtime behavior is unchanged. Thanks @ry4nyu for #306, and @szastupov for #304.
- TypeScript projects that type-check this package's sources with `tsc` now need `allowImportingTsExtensions: true` (with `noEmit` or `emitDeclarationOnly`); without it `tsc` reports TS5097 on the `.ts` import paths. Pi itself loads the sources through jiti and is unaffected.

## [2.13.8] - 2026-10-12

## [2.13.7] - 2026-10-12

## [2.13.6] - 2026-10-12

## [2.13.5] - 2026-10-12

## [2.13.4] - 2026-10-11

## [2.13.3] - 2026-10-11

## [2.13.2] - 2026-10-11

## [2.13.1] - 2026-10-11

## [2.13.0] - 2026-10-11

## [2.12.0] - 2026-09-30

### Fixed

- **`typebox` is declared as a `peerDependencies: "*"` entry, no longer a `dependencies` entry.** Pi provides `typebox` to extensions and aliases the bare specifier to its own bundled copy at load time, so the copy this manifest installed was dead weight at best and a second live instance at worst. Pi 0.99.1 warns at every startup about the old shape ("Host-provided extension packages must be declared in peerDependencies with a \"*\" range, not dependencies: typebox"); this clears it once the release is installed. Contributed in #282; reported in #266, #268, #272 and #277.

## [2.11.0] - 2026-09-21

## [2.10.1] - 2026-09-13

## [2.10.0] - 2026-09-12

## [2.9.0] - 2026-09-01

## [2.8.0] - 2026-08-29

## [2.7.1] - 2026-08-24

## [2.7.0] - 2026-08-21

## [2.6.4] - 2026-08-20

## [2.6.3] - 2026-08-20

## [2.6.2] - 2026-08-18

## [2.6.1] - 2026-08-17

### Added

- `GuidanceFields` (interface, `GuidanceFieldsSchema`, `validateGuidanceFields`) now supports an optional `description` field — kept when it is a non-empty string, dropped otherwise. Consumers that read `validateGuidanceFields` output and ignore the field are unaffected; consumers that compose `GuidanceFieldsSchema` into a `Value.Check`-validated config now reject a *wrong-typed* `description` (previously tolerated as an unknown key), so such consumers should degrade per field rather than per file.

## [2.6.0] - 2026-08-15

## [2.5.2] - 2026-08-14

## [2.5.1] - 2026-08-14

## [2.5.0] - 2026-08-13

## [2.4.0] - 2026-08-03

## [2.3.1] - 2026-07-31

## [2.3.0] - 2026-07-31

## [2.2.0] - 2026-07-29

## [2.1.0] - 2026-07-23

### Changed
- README rewritten to follow the documentation standard shared across all packages.

## [2.0.0] - 2026-07-21

### Added
- Add `resolveConfigDir()`, which honors `XDG_CONFIG_HOME` per the XDG spec: unset, empty, whitespace, or relative values fall back to `~/.config`; a leading `~/` is expanded (a `~user` form is not) and the result must be absolute.
- Add `loadJsonConfigWithLegacyFallback()`, which prefers the XDG config path and reads the legacy `~/.config` file only when the XDG file is absent; a malformed XDG file warns and returns an empty config rather than silently falling back.

### Fixed
- Load correctly under installers that do not materialize peer dependencies by declaring the schema library as a direct dependency.

## [1.20.0] - 2026-06-15

## [1.19.1] - 2026-06-10

## [1.19.0] - 2026-06-09

## [1.18.2] - 2026-06-04

## [1.18.1] - 2026-06-04

## [1.18.0] - 2026-06-04

### Added
- `modelKey` and `parseModelKey` are now exported from `@juicesharp/rpiv-config` (consolidated out of `rpiv-advisor`) so all consumers share one model-key codec.

### Changed
- `parseModelKey` now accepts both `provider/modelId` (canonical slash form) and `provider:modelId` (legacy colon form), preferring slash when both separators are present.
- `modelKey()` now emits only the canonical slash form (`provider/modelId`); it previously emitted `provider:modelId`. Paired with the tolerant read, persisted colon-form keys auto-migrate to slash on the next save by any consumer that re-serialises through the codec.

## [1.17.1] - 2026-06-01

## [1.17.0] - 2026-06-01

## [1.16.1] - 2026-05-30

## [1.16.0] - 2026-05-30

## [1.15.0] - 2026-05-28

### Added
- `GuidanceFieldsSchema` — TypeBox form of the existing `GuidanceFields` interface. For consumers composing larger TypeBox-validated config objects that need to declare a guidance subtree without redeclaring the leaf shape. Used internally by `rpiv-web-tools` Phase 4 config consolidation.

## [1.14.7] - 2026-05-28

## [1.14.6] - 2026-05-28

## [1.14.5] - 2026-05-28

## [1.14.4] - 2026-05-28

## [1.14.3] - 2026-05-28

## [1.14.2] - 2026-05-28

## [1.14.1] - 2026-05-28

## [1.14.0] - 2026-05-28

## [1.13.0] - 2026-05-25

## [1.12.0] - 2026-05-21

## [1.11.0] - 2026-05-20

## [1.10.2] - 2026-05-20

## [1.10.1] - 2026-05-19

## [1.10.0] - 2026-05-19

## [1.9.2] - 2026-05-19

## [1.9.1] - 2026-05-19

## [1.9.0] - 2026-05-18

## [1.8.3] - 2026-05-18

## [1.8.2] - 2026-05-17

## [1.8.1] - 2026-05-17

### Added
- Shared config I/O library with `configPath`, `loadJsonConfig`, `saveJsonConfig`, `readEnvVar`, and `validateConfig` helpers, extracted from the rpiv sibling packages.
- `saveJsonConfig` returns a boolean indicating persist success; callers guard user-facing notifications on the result.
- `loadJsonConfig` emits a `console.warn` diagnostic on malformed JSON and rejects array-root values.
